package ejercicio2_9;

public class Mostrador {

	public void put(int i) {
		// TODO Auto-generated method stub
		
	}

	public int get() {
		// TODO Auto-generated method stub
		return 0;
	}

}
