package ejercicio;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Letra extends Applet implements Runnable{

	Thread anima;
    int radio=10;       //radio de la pelota
    int x, y;     	//posici�n del centro de la pelota
    int dx = 1;         //desplazamientos
    int dy = 1;
    int anchoApplet;
    int altoApplet;
    int retardo=50;
    //Doble buffer
     Image imag;
     Graphics gBuffer;

     public void init () {
    	 setBackground(Color.white);
    	 anchoApplet=getSize().width;	//dimensiones del applet
    	 altoApplet=getSize().height;
    	 x=anchoApplet/4;			//posici�n inicial de partida
    	 y=altoApplet/2;  
     }
     
     public void start(){
    	 if(anima ==null){
    		 anima=new Thread(this);
    		 anima.start();
    	 }
     }

     public void stop(){
    	 if(anima!=null){
    		 anima.stop();
    		 anima=null;
    	 }
     }
     
     public void run() {
    	 long t=System.currentTimeMillis();
    	 while (true) {
    		 mover();
    		 try{
    			 t+=retardo;
    			 Thread.sleep(Math.max(0, t-System.currentTimeMillis()));
    		 }catch(InterruptedException ex){
    			 break;
    		 }
    	 }
     }
     
     void mover(){
    	 x += dx;
    	 y += dy;
     	if (x >= (anchoApplet-radio) || x <= radio) dx*= -1;
     	if (y >= (altoApplet-radio)  || y <= radio) dy*= -1;
     	repaint();		//llama a update
     }
     
     public void update(Graphics g){
    	 if(gBuffer==null){
    		 imag=createImage(anchoApplet, altoApplet);
    		 gBuffer=imag.getGraphics();
    	 }
    	 gBuffer.setColor(getBackground());
    	 gBuffer.fillRect(0,0, anchoApplet, altoApplet);
    	 //dibuja la pelota
    	 gBuffer.setColor(Color.red);
    	 gBuffer.fillOval(x-radio, y-radio, 2*radio, 2*radio);
    	 //transfiere la imagen al contexto gr�fico del applet
    	 g.drawImage(imag, 0, 0, null);
     }

     public void paint (Graphics g) {
    	 //se llama la primera vez que aparece el applet
     }
	
}
