package GestionVideojuegos;

/**
 * 
 * @author Miriam
 *
 */
public class PlataformaLista {
	/**
	 * 
	 * @return plataforma
	 */
	public String[] Lista(){
		String[] plataforma = {"DS", "WII", "XBOX", "PS2", "PS3", "PS4", "PC","ds","wii","xbox","ps2","ps3","ps4","pc"};
		return plataforma;
	}
}
