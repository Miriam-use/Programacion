//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci�n de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2020.10.02 a las 02:00:56 PM CEST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org/NewXMLSchema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package clasesdatos;
