package operaciones;

public class Main {

	public static void main(String[] args) {

		Operacion op = new Operacion();
		
		op.visualizarxml();
		
		op.crearProfesor("1", "Sara");
		
		op.visualizarxml();
	}

}
