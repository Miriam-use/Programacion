package ejercicio1_6;

public class Suma {

	public int sumar(int n1, int n2) {
		int resultado = 0;
		resultado=n1+n2;
		
		return resultado;
	}
}
