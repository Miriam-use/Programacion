package Ejercicio6;

public class PlazaDeAparcamiento {

	private int numplaza, aparcado;
	private Coche coche=null;
	private boolean libre=true;
	
	public PlazaDeAparcamiento() {
		this.numplaza=5;
	}
	
	public String getAparcarCoche() {
		
	}
	
}
